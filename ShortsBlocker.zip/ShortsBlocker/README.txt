طريقة التشغيل:
1) نزّل Android Studio وافتح فولدر ShortsBlocker (File > Open).
2) استنى الـ Gradle Sync يخلص.
3) وصّل موبايلك (USB debugging) واضغط Run، أو Build > Build APK(s).
4) افتح التطبيق، اضغط "فعّل الخدمة" وفعّل "قافل الشورتس" من إمكانية الوصول.
