package com.example.shortsblocker

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    private var lastActionTime = 0L
    private var strikes = 0
    
    private var wasInChat = false
    private var hasEditTextOnScreen = false
    private var isMainScreenUi = false

    private fun checkScreenState(node: AccessibilityNodeInfo?) {
        if (node == null) return
        
        // البحث عن مربع الكتابة
        if (node.className?.toString() == "android.widget.EditText") {
            hasEditTextOnScreen = true
        }
        
        // البحث عن زراير الشاشة الرئيسية لإنستجرام
        val viewId = node.viewIdResourceName ?: ""
        if (viewId.endsWith("id/clips_tab") || 
            viewId.endsWith("id/feed_tab") || 
            viewId.endsWith("id/profile_tab")) {
            isMainScreenUi = true
        }
        
        val desc = node.contentDescription?.toString() ?: ""
        if (desc.equals("Home", true) || desc.equals("الصفحة الرئيسية", true) ||
            desc.equals("Profile", true) || desc.equals("الملف الشخصي", true)) {
            isMainScreenUi = true
        }

        // لو لقينا الحاجتين، مفيش داعي نكمل تدوير
        if (hasEditTextOnScreen && isMainScreenUi) return

        for (i in 0 until node.childCount) {
            checkScreenState(node.getChild(i))
            if (hasEditTextOnScreen && isMainScreenUi) return
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        var inShorts = false

        if (pkg == INSTAGRAM) {
            if (!prefs.getBoolean("block_ig", true)) return
            
            inShorts = IG_IDS.any { id ->
                root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }
            }
            if (!inShorts) {
                val reelsNodes = root.findAccessibilityNodeInfosByText("Reels")
                val reelsArabic = root.findAccessibilityNodeInfosByText("ريلز")
                val clipsTab = root.findAccessibilityNodeInfosByViewId(IG_TAB_ID)
                
                inShorts = (reelsNodes + reelsArabic + clipsTab).any { 
                    it.isSelected || it.contentDescription?.contains("Reels", true) == true
                }
            }
        } else if (pkg == YOUTUBE) {
            if (!prefs.getBoolean("block_yt", true)) return
            
            inShorts = YT_IDS.any { id ->
                root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }
            }
            if (!inShorts) {
                val shortsNodes = root.findAccessibilityNodeInfosByText("Shorts")
                val shortsArabic = root.findAccessibilityNodeInfosByText("شورتس")
                inShorts = (shortsNodes + shortsArabic).any { it.isSelected }
            }
        } else {
            // لو التطبيق ولا إنستجرام ولا يوتيوب، وفر طاقة واخرج
            return 
        }

        // إلغاء تصريح الشات لو عملت سكرول (خاص بإنستجرام فقط)
        if (pkg == INSTAGRAM && inShorts && wasInChat && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val className = event.className?.toString() ?: ""
            if (className.contains("ViewPager") || className.contains("RecyclerView") || className.contains("ScrollView")) {
                wasInChat = false
            }
        }

        if (!inShorts) {
            // بنحسب حالة الشات في إنستجرام بس
            if (pkg == INSTAGRAM) {
                hasEditTextOnScreen = false
                isMainScreenUi = false
                checkScreenState(root)
                
                if (isMainScreenUi) {
                    wasInChat = false
                } else if (hasEditTextOnScreen) {
                    wasInChat = true
                }
            }
            return 
        } else {
            // لو إحنا جوه ريلز وجايين من الشات، سيبه يتفرج براحته
            if (pkg == INSTAGRAM && wasInChat) {
                return 
            }
        }

        // منطق الحجب (الضغط على زر الرجوع أو الهوم)
        val now = System.currentTimeMillis()
        if (now - lastActionTime < 800) return

        strikes = if (now - lastActionTime < 3000) strikes + 1 else 0
        lastActionTime = now

        if (strikes >= 2) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            strikes = 0
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    override fun onInterrupt() {}

    companion object {
        const val INSTAGRAM = "com.instagram.android"
        const val YOUTUBE = "com.google.android.youtube"

        val IG_IDS = listOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_root",
            "com.instagram.android:id/root_clips_layout",
            "com.instagram.android:id/clips_video_container"
        )
        const val IG_TAB_ID = "com.instagram.android:id/clips_tab"
        
        val YT_IDS = listOf(
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_player_page_container",
            "com.google.android.youtube:id/reel_watch_fragment_root"
        )
    }
}
