package com.example.shortsblocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    private var lastActionTime = 0L
    private var strikes = 0

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)

        val ids: List<String> = when (pkg) {
            INSTAGRAM -> {
                if (!prefs.getBoolean(MainActivity.KEY_IG, true)) return
                IG_IDS
            }
            YOUTUBE -> {
                if (!prefs.getBoolean(MainActivity.KEY_YT, true)) return
                YT_IDS
            }
            else -> return
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        var inShorts = ids.any { id ->
            root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }
        }
        // إشارة تانية لانستجرام: تاب Reels في الشريط السفلي يكون متحدد
        if (!inShorts && pkg == INSTAGRAM) {
            inShorts = root.findAccessibilityNodeInfosByViewId(IG_TAB_ID).any { it.isSelected }
        }
        if (!inShorts) return

        val now = System.currentTimeMillis()
        if (now - lastActionTime < 800) return

        // لو رجعناه ولسه في الشورتس في خلال 3 ثواني، نطلعه للهوم
        strikes = if (now - lastActionTime < 3000) strikes + 1 else 0
        lastActionTime = now

        if (strikes >= 2) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            strikes = 0
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    override fun onInterrupt() {}

    companion object {
        const val INSTAGRAM = "com.instagram.android"
        const val YOUTUBE = "com.google.android.youtube"

        // معرّفات الواجهة اللي بتظهر في Reels / Shorts (ممكن تتغير مع تحديثات التطبيقات)
        val IG_IDS = listOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_root",
            "com.instagram.android:id/root_clips_layout"
        )
        const val IG_TAB_ID = "com.instagram.android:id/clips_tab"
        val YT_IDS = listOf(
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_player_page_container",
            "com.google.android.youtube:id/reel_watch_fragment_root"
        )
    }
}
