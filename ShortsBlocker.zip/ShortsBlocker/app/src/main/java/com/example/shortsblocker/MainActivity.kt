package com.example.shortsblocker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        layout.addView(TextView(this).apply {
            text = "قافل الشورتس"
            textSize = 26f
            gravity = Gravity.START
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }
        layout.addView(status)

        layout.addView(Button(this).apply {
            text = "فعّل الخدمة من إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        layout.addView(makeSwitch("اقفل Instagram Reels", KEY_IG, prefs))
        layout.addView(makeSwitch("اقفل YouTube Shorts", KEY_YT, prefs))

        layout.addView(TextView(this).apply {
            text = "ملاحظة: لو الخدمة وقفت بعد إعادة تشغيل الموبايل، افتح إعدادات إمكانية الوصول وفعّلها تاني. وبعض الأجهزة (شاومي، سامسونج، أوبو) محتاجة تسمح للتطبيق يشتغل في الخلفية من إعدادات البطارية."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })

        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (isServiceEnabled()) "الحالة: شغّال ✅" else "الحالة: مش مفعّل ❌"
    }

    private fun makeSwitch(label: String, key: String, prefs: android.content.SharedPreferences) =
        Switch(this).apply {
            text = label
            textSize = 17f
            isChecked = prefs.getBoolean(key, true)
            setPadding(0, 32, 0, 32)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, BlockerService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return enabled.split(':').any {
            it.equals(full, ignoreCase = true) || it.equals(short, ignoreCase = true)
        }
    }

    companion object {
        const val PREFS = "prefs"
        const val KEY_IG = "block_ig"
        const val KEY_YT = "block_yt"
    }
}
