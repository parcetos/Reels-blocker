package com.example.shortsblocker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        // الشاشة الرئيسية (خلفية داكنة وتصميم بسيط)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#121212")) // Dark Minimalist Background
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // عنوان التطبيق
        layout.addView(TextView(this).apply {
            text = "Shorts Blocker"
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, pad)
        })

        // حالة الخدمة
        status = TextView(this).apply {
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, pad * 2)
        }
        layout.addView(status)

        // تصميم زرار التفعيل بحواف دائرية أنيقة
        val btnDrawable = GradientDrawable().apply {
            setColor(Color.parseColor("#292929"))
            cornerRadius = 16f * resources.displayMetrics.density
        }
        
        layout.addView(Button(this).apply {
            text = "Enable Accessibility Service"
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = btnDrawable
            textSize = 16f
            setPadding(pad, pad, pad, pad)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        // مسافة فاضية عشان تريح العين (Spacer)
        layout.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 
                (30 * resources.displayMetrics.density).toInt()
            )
        })

        // زراير التحكم (Switches)
        layout.addView(makeSwitch("Block Instagram Reels", KEY_IG, prefs))
        layout.addView(makeSwitch("Block YouTube Shorts", KEY_YT, prefs))

        // مسافة فاضية تانية
        layout.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 
                (40 * resources.displayMetrics.density).toInt()
            )
        })

        // الملاحظة في الأسفل (لون رمادي هادي)
        layout.addView(TextView(this).apply {
            text = "Note: If the blocker stops working after restarting your phone, please re-enable the Accessibility Service.\n\nSome devices (Xiaomi, Samsung, Oppo) may require you to allow background activity in battery settings."
            textSize = 13f
            setTextColor(Color.parseColor("#888888"))
            setLineSpacing(4f, 1.2f)
        })

        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (isServiceEnabled()) {
            status.text = "Status: Active 🟢"
            status.setTextColor(Color.parseColor("#4CAF50")) // لون أخضر مريح
        } else {
            status.text = "Status: Inactive 🔴"
            status.setTextColor(Color.parseColor("#F44336")) // لون أحمر هادي
        }
    }

    private fun makeSwitch(label: String, key: String, prefs: android.content.SharedPreferences): Switch {
        return Switch(this).apply {
            text = label
            textSize = 17f
            setTextColor(Color.parseColor("#E0E0E0"))
            isChecked = prefs.getBoolean(key, true)
            setPadding(0, 40, 0, 40)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, BlockerService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return enabled.split(':').any {
            it.equals(full, ignoreCase = true) || it.equals(short, ignoreCase = true)
        }
    }

    companion object {
        const val PREFS = "prefs"
        const val KEY_IG = "block_ig"
        const val KEY_YT = "block_yt"
    }
}
